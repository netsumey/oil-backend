use actix_web::{HttpResponse, web};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
pub struct DisplayRequest {
    name: String,
    count: bool,
    row_name: bool,
    amount: String,
}

pub async fn display_info(
    info: web::Json<DisplayRequest>
) -> actix_web::Result<HttpResponse> {
    let (name, count, row_name, amount) =
        (info.name.clone(), info.count, info.row_name,
         info.amount.parse::<usize>().unwrap_or(0));


}